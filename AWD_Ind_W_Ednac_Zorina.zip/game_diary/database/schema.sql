-- SeedVault: схема базы данных
CREATE DATABASE IF NOT EXISTS seedvault
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE seedvault;

CREATE TABLE IF NOT EXISTS users (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  username      VARCHAR(30)  NOT NULL UNIQUE,
  email         VARCHAR(100) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role          ENUM('user','admin') NOT NULL DEFAULT 'user',
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS biomes (
  id   INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS seeds (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  user_id     INT NOT NULL,
  biome_id    INT NOT NULL,
  title       VARCHAR(100) NOT NULL,
  seed_value  VARCHAR(25)  NOT NULL,
  edition     ENUM('java','bedrock') NOT NULL,
  version     VARCHAR(10)  NOT NULL,
  difficulty  ENUM('peaceful','easy','normal','hard') NOT NULL,
  has_village TINYINT(1) NOT NULL DEFAULT 0,
  description TEXT NOT NULL,
  image_url   VARCHAR(255) NULL,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_seed_user  FOREIGN KEY (user_id)  REFERENCES users(id)  ON DELETE CASCADE,
  CONSTRAINT fk_seed_biome FOREIGN KEY (biome_id) REFERENCES biomes(id) ON DELETE RESTRICT,
  INDEX idx_seeds_created (created_at),
  INDEX idx_seeds_filters (edition, biome_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS password_resets (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  user_id    INT NOT NULL,
  token_hash CHAR(64) NOT NULL,
  expires_at DATETIME NOT NULL,
  CONSTRAINT fk_reset_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_reset_token (token_hash)
) ENGINE=InnoDB;

INSERT IGNORE INTO biomes (name) VALUES
 ('Равнины'),('Пустыня'),('Джунгли'),('Тайга'),('Саванна'),
 ('Грибное поле'),('Горы'),('Болото'),('Вишнёвая роща');
