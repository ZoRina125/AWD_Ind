<?php
declare(strict_types=1);

/**
 * Точка входа (Front Controller): настройка окружения, сессии и маршрутов.
 */

// Автозагрузка: Composer (если установлен) + собственный PSR-4 загрузчик для App\
if (is_file(__DIR__ . '/../vendor/autoload.php')) {
    require __DIR__ . '/../vendor/autoload.php';
}
spl_autoload_register(static function (string $class): void {
    if (str_starts_with($class, 'App\\')) {
        $file = __DIR__ . '/../app/' . str_replace('\\', '/', substr($class, 4)) . '.php';
        if (is_file($file)) {
            require $file;
        }
    }
});

use App\Core\{Env, Router};
use App\Controllers\{HomeController, AuthController, SeedController, AdminController};

Env::load(__DIR__ . '/../.env');

/**
 * Короткий алиас для безопасного вывода в шаблонах.
 *
 * @param mixed $v Значение
 * @return string Экранированная строка
 */
function e(mixed $v): string
{
    return App\Core\View::e($v);
}

session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
session_start();

header('X-Frame-Options: DENY');
header('X-Content-Type-Options: nosniff');

$r = new Router();

// Публичная часть
$r->add('GET',  '/',              [HomeController::class, 'index']);
$r->add('GET',  '/seeds',         [SeedController::class, 'search']);

// Аутентификация и восстановление пароля
$r->add('GET',  '/register',      [AuthController::class, 'showRegister']);
$r->add('POST', '/register',      [AuthController::class, 'register']);
$r->add('GET',  '/login',         [AuthController::class, 'showLogin']);
$r->add('POST', '/login',         [AuthController::class, 'login']);
$r->add('POST', '/logout',        [AuthController::class, 'logout']);
$r->add('GET',  '/forgot',        [AuthController::class, 'showForgot']);
$r->add('POST', '/forgot',        [AuthController::class, 'forgot']);
$r->add('GET',  '/reset',         [AuthController::class, 'showReset']);
$r->add('POST', '/reset',         [AuthController::class, 'reset']);

// Сиды (порядок важен: /seeds/create раньше /seeds/{id})
$r->add('GET',  '/my',                  [SeedController::class, 'mine']);
$r->add('GET',  '/seeds/create',        [SeedController::class, 'showCreate']);
$r->add('POST', '/seeds/create',        [SeedController::class, 'create']);
$r->add('GET',  '/seeds/{id}',          [SeedController::class, 'show']);
$r->add('GET',  '/seeds/{id}/edit',     [SeedController::class, 'showEdit']);
$r->add('POST', '/seeds/{id}/edit',     [SeedController::class, 'update']);
$r->add('POST', '/seeds/{id}/delete',   [SeedController::class, 'delete']);

// Администратор
$r->add('GET',  '/admin',                    [AdminController::class, 'dashboard']);
$r->add('GET',  '/admin/users',              [AdminController::class, 'users']);
$r->add('POST', '/admin/users/{id}/role',    [AdminController::class, 'changeRole']);
$r->add('POST', '/admin/users/{id}/delete',  [AdminController::class, 'deleteUser']);
$r->add('GET',  '/admin/admins/create',      [AdminController::class, 'showCreateAdmin']);
$r->add('POST', '/admin/admins/create',      [AdminController::class, 'createAdmin']);
$r->add('GET',  '/admin/seeds',              [AdminController::class, 'seeds']);
$r->add('GET',  '/admin/biomes',             [AdminController::class, 'biomes']);
$r->add('POST', '/admin/biomes',             [AdminController::class, 'createBiome']);
$r->add('POST', '/admin/biomes/{id}/edit',   [AdminController::class, 'updateBiome']);
$r->add('POST', '/admin/biomes/{id}/delete', [AdminController::class, 'deleteBiome']);

try {
    $r->dispatch(
        $_SERVER['REQUEST_METHOD'],
        parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?: '/'
    );
} catch (PDOException $e) {
    http_response_code(500);
    error_log($e->getMessage());
    App\Core\View::render('error', [
        'code' => 500,
        'message' => 'Ошибка базы данных. Проверьте настройки в .env и что схема установлена (php bin/install.php).',
    ]);
}
