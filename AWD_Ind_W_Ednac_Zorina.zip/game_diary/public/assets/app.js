/**
 * Клиентская валидация форм (дублирует серверную, но даёт мгновенную обратную связь)
 * и вспомогательные действия. Формы с атрибутом data-validate проверяются
 * встроенным Constraint Validation API браузера.
 */
document.querySelectorAll('form[data-validate]').forEach((form) => {
  form.addEventListener('submit', (event) => {
    // дополнительные проверки, которые HTML5 не умеет
    const pass = form.querySelector('[name="password"]');
    const conf = form.querySelector('[name="password_confirm"]');
    if (pass && conf) {
      conf.setCustomValidity(pass.value === conf.value ? '' : 'Пароли не совпадают');
    }
    if (!form.checkValidity()) {
      event.preventDefault();
      event.stopPropagation();
    }
    form.classList.add('was-validated');
  });
});

// Счётчик символов для textarea с maxlength
document.querySelectorAll('textarea[maxlength]').forEach((area) => {
  const hint = document.createElement('div');
  hint.className = 'form-text text-end';
  area.insertAdjacentElement('afterend', hint);
  const update = () => { hint.textContent = area.value.length + ' / ' + area.maxLength; };
  area.addEventListener('input', update);
  update();
});

// Копирование сида по кнопке
document.querySelectorAll('[data-copy]').forEach((btn) => {
  btn.addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(btn.dataset.copy);
      const old = btn.textContent;
      btn.textContent = 'Скопировано!';
      setTimeout(() => { btn.textContent = old; }, 1500);
    } catch (e) { /* буфер обмена недоступен */ }
  });
});

// Подтверждение опасных действий
document.querySelectorAll('form[data-confirm]').forEach((form) => {
  form.addEventListener('submit', (event) => {
    if (!window.confirm(form.dataset.confirm)) {
      event.preventDefault();
    }
  });
});
