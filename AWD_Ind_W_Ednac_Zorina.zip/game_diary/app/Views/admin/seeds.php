<?php require __DIR__ . '/_menu.php'; ?>
<h1 class="h3 mb-3">Все сиды</h1>
<div class="table-responsive"><table class="table align-middle table-sm">
  <thead><tr><th>ID</th><th>Название</th><th>Автор</th><th>Биом</th><th>Версия</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($seeds as $s): ?>
    <tr><td><?= (int)$s['id'] ?></td><td><a href="/seeds/<?= (int)$s['id'] ?>"><?= e($s['title']) ?></a></td>
      <td><?= e($s['username']) ?></td><td><?= e($s['biome']) ?></td><td><?= e($s['version']) ?></td>
      <td class="text-end">
        <a class="btn btn-sm btn-outline-primary" href="/seeds/<?= (int)$s['id'] ?>/edit">Изменить</a>
        <form method="post" action="/seeds/<?= (int)$s['id'] ?>/delete" class="d-inline" data-confirm="Удалить сид?"><?= App\Core\Csrf::field() ?>
          <button class="btn btn-sm btn-outline-danger">Удалить</button></form></td></tr>
  <?php endforeach; ?>
  </tbody></table></div>
