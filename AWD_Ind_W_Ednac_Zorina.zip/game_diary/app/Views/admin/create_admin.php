<?php require __DIR__ . '/_menu.php'; $err = fn(string $k) => $errors[$k] ?? null; ?>
<div class="row"><div class="col-md-6">
  <h1 class="h3 mb-3">Создать администратора</h1>
  <form method="post" action="/admin/admins/create" data-validate novalidate>
    <?= App\Core\Csrf::field() ?>
    <div class="mb-3"><label class="form-label" for="username">Ник</label>
      <input class="form-control <?= $err('username') ? 'is-invalid' : '' ?>" id="username" name="username" value="<?= e($old['username'] ?? '') ?>" required pattern="[A-Za-z0-9_]{3,30}">
      <div class="invalid-feedback"><?= e($err('username') ?? 'Ник: 3-30 символов, латиница, цифры и _.') ?></div></div>
    <div class="mb-3"><label class="form-label" for="email">Email</label>
      <input class="form-control <?= $err('email') ? 'is-invalid' : '' ?>" type="email" id="email" name="email" value="<?= e($old['email'] ?? '') ?>" required>
      <div class="invalid-feedback"><?= e($err('email') ?? 'Введите корректный email.') ?></div></div>
    <div class="mb-3"><label class="form-label" for="password">Пароль</label>
      <input class="form-control <?= $err('password') ? 'is-invalid' : '' ?>" type="password" id="password" name="password" required minlength="8" pattern="(?=.*[A-Za-z])(?=.*\d).{8,72}">
      <div class="invalid-feedback"><?= e($err('password') ?? 'Минимум 8 символов, буквы и цифры.') ?></div></div>
    <button class="btn btn-warning">Создать администратора</button>
  </form>
</div></div>
