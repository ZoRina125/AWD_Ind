<?php require __DIR__ . '/_menu.php'; ?>
<h1 class="h3 mb-3">Админ-панель</h1>
<div class="row g-3 mb-4">
  <div class="col-6"><div class="card stat-box"><div class="card-body"><div class="fs-2 fw-bold"><?= (int)$usersTotal ?></div>пользователей</div></div></div>
  <div class="col-6"><div class="card stat-box"><div class="card-body"><div class="fs-2 fw-bold"><?= (int)$seedsTotal ?></div>сидов</div></div></div>
</div>
<div class="row g-4">
  <div class="col-md-6"><h2 class="h5">Сиды по биомам</h2>
    <ul class="list-group"><?php foreach ($biomes as $b): ?>
      <li class="list-group-item d-flex justify-content-between"><?= e($b['name']) ?><span class="badge text-bg-success rounded-pill"><?= (int)$b['cnt'] ?></span></li>
    <?php endforeach; ?></ul></div>
  <div class="col-md-6"><h2 class="h5">Топ авторов</h2>
    <ul class="list-group"><?php foreach ($authors as $a): ?>
      <li class="list-group-item d-flex justify-content-between"><?= e($a['username']) ?><span class="badge text-bg-secondary rounded-pill"><?= (int)$a['cnt'] ?></span></li>
    <?php endforeach; ?></ul></div>
</div>
