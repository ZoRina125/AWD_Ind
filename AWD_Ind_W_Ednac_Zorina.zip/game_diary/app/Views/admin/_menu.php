<ul class="nav nav-pills mb-4">
  <li class="nav-item"><a class="nav-link" href="/admin">Статистика</a></li>
  <li class="nav-item"><a class="nav-link" href="/admin/users">Пользователи</a></li>
  <li class="nav-item"><a class="nav-link" href="/admin/admins/create">Новый админ</a></li>
  <li class="nav-item"><a class="nav-link" href="/admin/seeds">Сиды</a></li>
  <li class="nav-item"><a class="nav-link" href="/admin/biomes">Биомы</a></li>
</ul>
