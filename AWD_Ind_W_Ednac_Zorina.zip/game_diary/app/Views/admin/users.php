<?php require __DIR__ . '/_menu.php'; ?>
<h1 class="h3 mb-3">Пользователи</h1>
<div class="table-responsive"><table class="table align-middle">
  <thead><tr><th>ID</th><th>Ник</th><th>Email</th><th>Роль</th><th>Сидов</th><th>Регистрация</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($users as $u): $self = (int)$u['id'] === App\Core\Auth::id(); ?>
    <tr><td><?= (int)$u['id'] ?></td><td><?= e($u['username']) ?><?= $self ? ' <span class="badge text-bg-info">это вы</span>' : '' ?></td>
      <td><?= e($u['email']) ?></td>
      <td><span class="badge text-bg-<?= $u['role'] === 'admin' ? 'warning' : 'secondary' ?>"><?= e($u['role']) ?></span></td>
      <td><?= (int)$u['seeds_count'] ?></td><td><?= e(date('d.m.Y', strtotime($u['created_at']))) ?></td>
      <td class="text-end"><?php if (!$self): ?>
        <form method="post" action="/admin/users/<?= (int)$u['id'] ?>/role" class="d-inline"><?= App\Core\Csrf::field() ?>
          <input type="hidden" name="role" value="<?= $u['role'] === 'admin' ? 'user' : 'admin' ?>">
          <button class="btn btn-sm btn-outline-primary"><?= $u['role'] === 'admin' ? 'Сделать user' : 'Сделать admin' ?></button></form>
        <form method="post" action="/admin/users/<?= (int)$u['id'] ?>/delete" class="d-inline" data-confirm="Удалить пользователя и все его сиды?"><?= App\Core\Csrf::field() ?>
          <button class="btn btn-sm btn-outline-danger">Удалить</button></form>
      <?php endif; ?></td></tr>
  <?php endforeach; ?>
  </tbody></table></div>
