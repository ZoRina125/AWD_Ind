<?php require __DIR__ . '/_menu.php'; ?>
<h1 class="h3 mb-3">Справочник биомов</h1>
<form method="post" action="/admin/biomes" class="row g-2 mb-4" data-validate novalidate>
  <?= App\Core\Csrf::field() ?>
  <div class="col-md-6"><input class="form-control" name="name" placeholder="Новый биом" required minlength="2" maxlength="50">
    <div class="invalid-feedback">Название: от 2 до 50 символов.</div></div>
  <div class="col-auto"><button class="btn btn-success">Добавить</button></div>
</form>
<table class="table align-middle biome-table">
  <thead><tr><th>ID</th><th>Название</th><th>Сидов</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($biomes as $b): ?>
    <tr><td><?= (int)$b['id'] ?></td>
      <td><form method="post" action="/admin/biomes/<?= (int)$b['id'] ?>/edit" class="d-flex gap-2"><?= App\Core\Csrf::field() ?>
        <input class="form-control form-control-sm" name="name" value="<?= e($b['name']) ?>" required minlength="2" maxlength="50">
        <button class="btn btn-sm btn-outline-primary">Сохранить</button></form></td>
      <td><?= (int)$b['cnt'] ?></td>
      <td class="text-end"><form method="post" action="/admin/biomes/<?= (int)$b['id'] ?>/delete" data-confirm="Удалить биом?"><?= App\Core\Csrf::field() ?>
        <button class="btn btn-sm btn-outline-danger">Удалить</button></form></td></tr>
  <?php endforeach; ?>
  </tbody></table>
