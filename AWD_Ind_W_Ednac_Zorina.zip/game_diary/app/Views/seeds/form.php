<?php
use App\Models\Seed;
$err = fn(string $k) => $errors[$k] ?? null;
$cls = fn(string $k) => isset($errors[$k]) ? 'is-invalid' : '';
$val = fn(string $k, $d = '') => $old[$k] ?? $d;
?>
<div class="row justify-content-center">
  <div class="col-lg-8">
    <div class="add-seed-panel">
  <h1 class="h3 mb-3"><?= e($heading) ?></h1>
  <?php if ($errors): ?><div class="alert alert-danger">Исправьте ошибки в форме и отправьте её снова.</div><?php endif; ?>
  <form method="post" action="<?= e($action) ?>" data-validate novalidate>
    <?= App\Core\Csrf::field() ?>

    <div class="mb-3"><label class="form-label" for="title">Название *</label>
      <input class="form-control <?= $cls('title') ?>" id="title" name="title" value="<?= e($val('title')) ?>" required minlength="3" maxlength="100">
      <div class="invalid-feedback"><?= e($err('title') ?? 'Название: от 3 до 100 символов.') ?></div></div>

    <div class="mb-3"><label class="form-label" for="seed_value">Сид (число) *</label>
      <input class="form-control <?= $cls('seed_value') ?>" id="seed_value" name="seed_value" value="<?= e($val('seed_value')) ?>" required pattern="-?\d{1,19}" inputmode="numeric" placeholder="-4172144997902289642">
      <div class="invalid-feedback"><?= e($err('seed_value') ?? 'Целое число, можно со знаком минус.') ?></div></div>

    <div class="mb-3 radio-group"><label class="form-label d-block">Редакция *</label>
      <?php foreach (Seed::EDITIONS as $k => $v): ?>
        <div class="form-check form-check-inline">
          <input class="form-check-input <?= $cls('edition') ?>" type="radio" name="edition" id="ed_<?= e($k) ?>" value="<?= e($k) ?>" <?= $val('edition') === $k ? 'checked' : '' ?> required>
          <label class="form-check-label" for="ed_<?= e($k) ?>"><?= e($v) ?></label>
        </div>
      <?php endforeach; ?>
      <div class="invalid-feedback <?= $err('edition') ? 'd-block' : '' ?>"><?= e($err('edition') ?? 'Выберите редакцию игры.') ?></div></div>

    <div class="row">
      <div class="col-md-4 mb-3"><label class="form-label" for="version">Версия *</label>
        <select class="form-select <?= $cls('version') ?>" id="version" name="version" required>
          <option value="">Выберите...</option>
          <?php foreach (Seed::VERSIONS as $v): ?><option <?= $val('version') === $v ? 'selected' : '' ?>><?= e($v) ?></option><?php endforeach; ?>
        </select><div class="invalid-feedback"><?= e($err('version') ?? 'Выберите версию.') ?></div></div>
      <div class="col-md-4 mb-3"><label class="form-label" for="biome_id">Биом *</label>
        <select class="form-select <?= $cls('biome_id') ?>" id="biome_id" name="biome_id" required>
          <option value="">Выберите...</option>
          <?php foreach ($biomes as $b): ?><option value="<?= (int)$b['id'] ?>" <?= (int)$val('biome_id', 0) === (int)$b['id'] ? 'selected' : '' ?>><?= e($b['name']) ?></option><?php endforeach; ?>
        </select><div class="invalid-feedback"><?= e($err('biome_id') ?? 'Выберите биом.') ?></div></div>
      <div class="col-md-4 mb-3"><label class="form-label" for="difficulty">Сложность *</label>
        <select class="form-select <?= $cls('difficulty') ?>" id="difficulty" name="difficulty" required>
          <option value="">Выберите...</option>
          <?php foreach (Seed::DIFFICULTIES as $k => $v): ?><option value="<?= e($k) ?>" <?= $val('difficulty') === $k ? 'selected' : '' ?>><?= e($v) ?></option><?php endforeach; ?>
        </select><div class="invalid-feedback"><?= e($err('difficulty') ?? 'Выберите сложность.') ?></div></div>
    </div>

    <div class="form-check form-switch mb-3">
      <input class="form-check-input" type="checkbox" role="switch" id="has_village" name="has_village" value="1" <?= !empty($old['has_village']) ? 'checked' : '' ?>>
      <label class="form-check-label" for="has_village">Рядом со спавном есть деревня</label></div>

    <div class="mb-3"><label class="form-label" for="description">Описание *</label>
      <textarea class="form-control <?= $cls('description') ?>" id="description" name="description" rows="5" required minlength="10" maxlength="2000"><?= e($val('description')) ?></textarea>
      <div class="invalid-feedback"><?= e($err('description') ?? 'Описание: от 10 до 2000 символов.') ?></div></div>

    <div class="mb-3"><label class="form-label" for="image_url">Ссылка на скриншот (необязательно)</label>
      <input class="form-control <?= $cls('image_url') ?>" type="url" id="image_url" name="image_url" value="<?= e($val('image_url')) ?>" maxlength="255" placeholder="https://...">
      <div class="invalid-feedback"><?= e($err('image_url') ?? 'Введите корректную ссылку (http/https).') ?></div></div>

    <button class="btn btn-success">Сохранить</button>
    <a href="/my" class="btn btn-outline-secondary">Отмена</a>
  </form>
    </div>
  </div>
</div>
