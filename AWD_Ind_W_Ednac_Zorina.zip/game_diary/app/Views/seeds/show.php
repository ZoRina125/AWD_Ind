<?php use App\Models\Seed; ?>
<div class="row g-4">
  <div class="col-lg-7">
    <?php if ($seed['image_url']): ?>
      <img src="<?= e($seed['image_url']) ?>" class="img-fluid rounded" alt="Скриншот: <?= e($seed['title']) ?>" referrerpolicy="no-referrer">
    <?php else: ?><div class="seed-thumb-empty rounded" style="height:300px">&#127807;</div><?php endif; ?>
  </div>
  <div class="col-lg-5 seed-detail-panel">
    <h1 class="h3"><?= e($seed['title']) ?></h1>
    <p class="text-muted">Автор: <?= e($seed['username']) ?> &middot; <?= e(date('d.m.Y', strtotime($seed['created_at']))) ?></p>
    <div class="input-group mb-3">
      <span class="input-group-text">Сид</span>
      <code class="form-control seed-code"><?= e($seed['seed_value']) ?></code>
      <button class="btn btn-outline-success" type="button" data-copy="<?= e($seed['seed_value']) ?>">Копировать</button>
    </div>
    <table class="table table-sm">
      <tr><th>Редакция</th><td><?= e(Seed::EDITIONS[$seed['edition']]) ?></td></tr>
      <tr><th>Версия</th><td><?= e($seed['version']) ?></td></tr>
      <tr><th>Биом</th><td><?= e($seed['biome']) ?></td></tr>
      <tr><th>Сложность</th><td><?= e(Seed::DIFFICULTIES[$seed['difficulty']]) ?></td></tr>
      <tr><th>Деревня у спавна</th><td><?= $seed['has_village'] ? 'Да' : 'Нет' ?></td></tr>
    </table>
    <p><?= nl2br(e($seed['description'])) ?></p>
    <?php if ($canEdit): ?>
      <a class="btn btn-outline-primary btn-sm" href="/seeds/<?= (int)$seed['id'] ?>/edit">Редактировать</a>
      <form method="post" action="/seeds/<?= (int)$seed['id'] ?>/delete" class="d-inline" data-confirm="Удалить этот сид?">
        <?= App\Core\Csrf::field() ?><button class="btn btn-outline-danger btn-sm">Удалить</button></form>
    <?php endif; ?>
  </div>
</div>
