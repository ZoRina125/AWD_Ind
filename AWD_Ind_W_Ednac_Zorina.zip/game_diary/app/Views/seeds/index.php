<?php
use App\Models\Seed;
$items = $result['items'];
$query = $_GET; unset($query['page']);
?>
<h1 class="h3 mb-3">Поиск сидов</h1>
<form method="get" action="/seeds" class="card card-body mb-4">
  <div class="row g-3">
    <div class="col-md-6"><label class="form-label" for="q">Ключевое слово</label>
      <input class="form-control" id="q" name="q" value="<?= e($filters['q']) ?>" placeholder="название, описание или номер сида"></div>
    <div class="col-md-3"><label class="form-label" for="edition">Редакция</label>
      <select class="form-select" id="edition" name="edition"><option value="">Любая</option>
        <?php foreach (Seed::EDITIONS as $k => $v): ?><option value="<?= e($k) ?>" <?= $filters['edition'] === $k ? 'selected' : '' ?>><?= e($v) ?></option><?php endforeach; ?>
      </select></div>
    <div class="col-md-3"><label class="form-label" for="version">Версия</label>
      <select class="form-select" id="version" name="version"><option value="">Любая</option>
        <?php foreach (Seed::VERSIONS as $v): ?><option <?= $filters['version'] === $v ? 'selected' : '' ?>><?= e($v) ?></option><?php endforeach; ?>
      </select></div>
    <div class="col-md-4"><label class="form-label" for="biome_id">Биом</label>
      <select class="form-select" id="biome_id" name="biome_id"><option value="">Любой</option>
        <?php foreach ($biomes as $b): ?><option value="<?= (int)$b['id'] ?>" <?= (string)$filters['biome_id'] === (string)$b['id'] ? 'selected' : '' ?>><?= e($b['name']) ?></option><?php endforeach; ?>
      </select></div>
    <div class="col-md-4"><label class="form-label" for="difficulty">Сложность</label>
      <select class="form-select" id="difficulty" name="difficulty"><option value="">Любая</option>
        <?php foreach (Seed::DIFFICULTIES as $k => $v): ?><option value="<?= e($k) ?>" <?= $filters['difficulty'] === $k ? 'selected' : '' ?>><?= e($v) ?></option><?php endforeach; ?>
      </select></div>
    <div class="col-md-4 d-flex align-items-end"><div class="form-check form-switch">
      <input class="form-check-input" type="checkbox" role="switch" id="has_village" name="has_village" value="1" <?= $filters['has_village'] ? 'checked' : '' ?>>
      <label class="form-check-label" for="has_village">Только с деревней у спавна</label></div></div>
  </div>
  <div class="mt-3"><button class="btn btn-success">Найти</button> <a class="btn btn-outline-secondary" href="/seeds">Сбросить</a></div>
</form>

<p class="text-muted">Найдено: <?= (int)$result['total'] ?></p>
<div class="row g-3">
  <?php foreach ($items as $s): ?><div class="col-md-6 col-lg-4"><?php require __DIR__ . '/../partials_card.php'; ?></div><?php endforeach; ?>
  <?php if (!$items): ?><p class="text-muted">Ничего не найдено. Попробуйте изменить фильтры.</p><?php endif; ?>
</div>

<?php if ($result['pages'] > 1): ?>
<nav class="mt-4"><ul class="pagination justify-content-center">
  <?php for ($p = 1; $p <= $result['pages']; $p++): ?>
    <li class="page-item <?= $p === $result['page'] ? 'active' : '' ?>">
      <a class="page-link" href="/seeds?<?= e(http_build_query($query + ['page' => $p])) ?>"><?= $p ?></a></li>
  <?php endfor; ?>
</ul></nav>
<?php endif; ?>
