<div class="d-flex justify-content-between align-items-center mb-3">
  <h1 class="h3 mb-0">Мои сиды</h1>
  <a class="btn btn-success" href="/seeds/create">+ Добавить сид</a>
</div>
<?php if (!$seeds): ?><p class="text-muted">Вы ещё не добавляли сиды.</p><?php else: ?>
<div class="table-responsive"><table class="table align-middle">
  <thead><tr><th>Название</th><th>Биом</th><th>Версия</th><th>Дата</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($seeds as $s): ?>
    <tr><td><a href="/seeds/<?= (int)$s['id'] ?>"><?= e($s['title']) ?></a></td>
      <td><?= e($s['biome']) ?></td><td><?= e($s['version']) ?></td>
      <td><?= e(date('d.m.Y', strtotime($s['created_at']))) ?></td>
      <td class="text-end">
        <a class="btn btn-sm btn-outline-primary" href="/seeds/<?= (int)$s['id'] ?>/edit">Изменить</a>
        <form method="post" action="/seeds/<?= (int)$s['id'] ?>/delete" class="d-inline" data-confirm="Удалить сид?">
          <?= App\Core\Csrf::field() ?><button class="btn btn-sm btn-outline-danger">Удалить</button></form>
      </td></tr>
  <?php endforeach; ?>
  </tbody></table></div>
<?php endif; ?>
