
<?php
/** Карточка сида. Ожидает переменную $s */
?>
<div class="card h-100 seed-card">
    <?php if (!empty($s['image_url'])): ?>
        <img src="<?= e($s['image_url']) ?>"
             class="card-img-top seed-thumb"
             alt="Скриншот: <?= e($s['title']) ?>"
             loading="lazy"
             referrerpolicy="no-referrer">
    <?php else: ?>
        <div class="seed-thumb-empty">&#127807;</div>
    <?php endif; ?>

    <div class="card-body">
        <h5 class="card-title">
            <a href="/seeds/<?= (int)$s['id'] ?>"
               class="stretched-link text-decoration-none">
                <?= e($s['title']) ?>
            </a>
        </h5>

        <div class="mb-2">
            <span class="badge text-bg-success"><?= e($s['biome']) ?></span>
            <span class="badge text-bg-secondary">
                <?= e(App\Models\Seed::EDITIONS[$s['edition']]) ?>
                <?= e($s['version']) ?>
            </span>

            <?php if ($s['has_village']): ?>
                <span class="badge text-bg-warning">Деревня</span>
            <?php endif; ?>
        </div>

        <p class="card-text small mb-0">
            Сид: <code><?= e($s['seed_value']) ?></code><br>
            Автор: <?= e($s['username']) ?>
        </p>
    </div>
</div>
