
 <?php
use App\Core\{Auth, Csrf, Flash};
?><!doctype html>
<html lang="ru">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($title) ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="/assets/style.css" rel="stylesheet">
</head>
<body class="d-flex flex-column min-vh-100">
<nav class="navbar navbar-expand-lg navbar-dark sv-nav">
  <div class="container">
    <a class="navbar-brand fw-bold" href="/"> SeedVault</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav"><span class="navbar-toggler-icon"></span></button>
    <div class="collapse navbar-collapse" id="nav">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link" href="/seeds">Поиск сидов</a></li>
        <?php if (Auth::check()): ?>
          <li class="nav-item"><a class="nav-link" href="/seeds/create">Добавить сид</a></li>
          <li class="nav-item"><a class="nav-link" href="/my">Мои сиды</a></li>
        <?php endif; ?>
        <?php if (Auth::isAdmin()): ?>
          <li class="nav-item"><a class="nav-link text-warning" href="/admin">Админ-панель</a></li>
        <?php endif; ?>
      </ul>
      <div class="d-flex align-items-center gap-2">
        <?php if (Auth::check()): ?>
          <span class="text-light small"><?= e($_SESSION['username']) ?><?= Auth::isAdmin() ? ' (admin)' : '' ?></span>
          <form method="post" action="/logout" class="m-0"><?= Csrf::field() ?>
            <button class="btn btn-outline-light btn-sm">Выйти</button></form>
        <?php else: ?>
          <a class="btn btn-outline-light btn-sm" href="/login">Войти</a>
          <a class="btn btn-success btn-sm" href="/register">Регистрация</a>
        <?php endif; ?>
      </div>
    </div>
  </div>
</nav>

<main class="container my-4 flex-grow-1">
  <?php foreach (Flash::pull() as $f): ?>
    <div class="alert alert-<?= e($f['type']) ?> alert-dismissible fade show" role="alert">
      <?= e($f['message']) ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Закрыть"></button>
    </div>
  <?php endforeach; ?>
  <?= $content ?>
</main>

<footer class="text-center text-muted small py-3 border-top">SeedVault &middot; учебный проект</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="/assets/app.js"></script>
</body>
</html>
