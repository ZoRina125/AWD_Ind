
<div class="hero-block p-4 p-md-5 mb-4 rounded-3">
  <div class="hero-text">
    <h1 class="display-5 fw-bold">Найди идеальный мир Minecraft</h1>
    <p class="lead mb-3">Делитесь сидами, находите деревни, горы и редкие биомы прямо у спавна.</p>
  </div>

  <form action="/seeds" method="get" class="row g-2">
    <div class="col-md-8">
      <input class="form-control form-control-lg" name="q" placeholder="Например: деревня у горы">
    </div>
    <div class="col-md-4">
      <button class="btn btn-success btn-lg w-100">Искать сиды</button>
    </div>
  </form>
</div>

<div class="row g-3 mb-4">
  <div class="col-6"><div class="card stat-box"><div class="card-body"><div class="fs-2 fw-bold"><?= (int)$seedsTotal ?></div>сидов в каталоге</div></div></div>
  <div class="col-6"><div class="card stat-box"><div class="card-body"><div class="fs-2 fw-bold"><?= (int)$usersTotal ?></div>участников</div></div></div>
</div>

<h2 class="h4 mb-3">Последние сиды</h2>
<div class="row g-3 mb-4">
  <?php foreach ($latest as $s): ?>
    <div class="col-md-6 col-lg-4"><?php require __DIR__ . '/partials_card.php'; ?></div>
  <?php endforeach; ?>
  <?php if (!$latest): ?><p class="text-muted">Пока нет сидов. <a href="/seeds/create">Добавьте первый!</a></p><?php endif; ?>
</div>

<div class="row g-4">
  <div class="col-md-6">
    <h2 class="h5">Популярные биомы</h2>
    <ul class="list-group">
      <?php foreach ($popular as $b): ?>
        <li class="list-group-item d-flex justify-content-between">
          <a href="/seeds?biome_id=<?= (int)$b['id'] ?>"><?= e($b['name']) ?></a>
          <span class="badge text-bg-success rounded-pill"><?= (int)$b['cnt'] ?></span>
        </li>
      <?php endforeach; ?>
    </ul>
  </div>
  <div class="col-md-6">
    <h2 class="h5">Лучшие авторы</h2>
    <ul class="list-group">
      <?php foreach ($authors as $a): ?>
        <li class="list-group-item d-flex justify-content-between"><?= e($a['username']) ?>
          <span class="badge text-bg-secondary rounded-pill"><?= (int)$a['cnt'] ?></span></li>
      <?php endforeach; ?>
      <?php if (!$authors): ?><li class="list-group-item text-muted">Пока никого</li><?php endif; ?>
    </ul>
  </div>
</div>
