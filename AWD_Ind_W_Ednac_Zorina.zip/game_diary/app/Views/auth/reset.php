<?php $err = fn(string $k) => $errors[$k] ?? null; ?>
<div class="row justify-content-center"><div class="col-md-5">
  <h1 class="h3 mb-3">Новый пароль</h1>
  <form method="post" action="/reset" data-validate novalidate>
    <?= App\Core\Csrf::field() ?>
    <input type="hidden" name="token" value="<?= e($token) ?>">
    <div class="mb-3"><label class="form-label" for="password">Новый пароль</label>
      <input class="form-control <?= $err('password') ? 'is-invalid' : '' ?>" type="password" id="password" name="password"
             required minlength="8" maxlength="72" pattern="(?=.*[A-Za-z])(?=.*\d).{8,72}">
      <div class="invalid-feedback"><?= e($err('password') ?? 'Минимум 8 символов, буквы и цифры.') ?></div></div>
    <div class="mb-3"><label class="form-label" for="password_confirm">Повторите пароль</label>
      <input class="form-control <?= $err('password_confirm') ? 'is-invalid' : '' ?>" type="password" id="password_confirm" name="password_confirm" required>
      <div class="invalid-feedback"><?= e($err('password_confirm') ?? 'Пароли не совпадают.') ?></div></div>
    <button class="btn btn-success w-100">Сохранить пароль</button>
  </form>
</div></div>
