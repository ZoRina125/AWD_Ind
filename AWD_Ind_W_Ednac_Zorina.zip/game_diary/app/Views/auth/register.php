<?php $err = fn(string $k) => $errors[$k] ?? null; ?>
<div class="row justify-content-center"><div class="col-md-6">
  <h1 class="h3 mb-3">Регистрация</h1>
  <form method="post" action="/register" data-validate novalidate>
    <?= App\Core\Csrf::field() ?>
    <div class="mb-3"><label class="form-label" for="username">Ник</label>
      <input class="form-control <?= $err('username') ? 'is-invalid' : '' ?>" id="username" name="username"
             value="<?= e($old['username'] ?? '') ?>" required pattern="[A-Za-z0-9_]{3,30}" maxlength="30">
      <div class="invalid-feedback"><?= e($err('username') ?? 'Ник: 3-30 символов, латиница, цифры и _.') ?></div></div>
    <div class="mb-3"><label class="form-label" for="email">Email</label>
      <input class="form-control <?= $err('email') ? 'is-invalid' : '' ?>" type="email" id="email" name="email"
             value="<?= e($old['email'] ?? '') ?>" required maxlength="100">
      <div class="invalid-feedback"><?= e($err('email') ?? 'Введите корректный email.') ?></div></div>
    <div class="mb-3"><label class="form-label" for="password">Пароль</label>
      <input class="form-control <?= $err('password') ? 'is-invalid' : '' ?>" type="password" id="password" name="password"
             required minlength="8" maxlength="72" pattern="(?=.*[A-Za-z])(?=.*\d).{8,72}">
      <div class="invalid-feedback"><?= e($err('password') ?? 'Минимум 8 символов, буквы и цифры.') ?></div></div>
    <div class="mb-3"><label class="form-label" for="password_confirm">Повторите пароль</label>
      <input class="form-control <?= $err('password_confirm') ? 'is-invalid' : '' ?>" type="password" id="password_confirm" name="password_confirm" required>
      <div class="invalid-feedback"><?= e($err('password_confirm') ?? 'Пароли не совпадают.') ?></div></div>
    <button class="btn btn-success w-100">Создать аккаунт</button>
  </form>
</div></div>
