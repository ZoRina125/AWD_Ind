<div class="row justify-content-center"><div class="col-md-5">
  <h1 class="h3 mb-3">Восстановление пароля</h1>
  <?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
  <form method="post" action="/forgot" data-validate novalidate>
    <?= App\Core\Csrf::field() ?>
    <div class="mb-3"><label class="form-label" for="email">Email аккаунта</label>
      <input class="form-control" type="email" id="email" name="email" required>
      <div class="invalid-feedback">Введите корректный email.</div></div>
    <button class="btn btn-success w-100">Отправить ссылку</button>
  </form>
</div></div>
