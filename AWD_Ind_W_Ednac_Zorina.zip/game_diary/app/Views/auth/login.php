<div class="row justify-content-center"><div class="col-md-5">
  <h1 class="h3 mb-3">Вход</h1>
  <?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
  <form method="post" action="/login" data-validate novalidate>
    <?= App\Core\Csrf::field() ?>
    <div class="mb-3"><label class="form-label" for="username">Ник</label>
      <input class="form-control" id="username" name="username" value="<?= e($old) ?>" required autofocus>
      <div class="invalid-feedback">Введите ник.</div></div>
    <div class="mb-3"><label class="form-label" for="password">Пароль</label>
      <input class="form-control" type="password" id="password" name="password" required>
      <div class="invalid-feedback">Введите пароль.</div></div>
    <button class="btn btn-success w-100">Войти</button>
  </form>
  <p class="mt-3 small"><a href="/forgot">Забыли пароль?</a> &middot; <a href="/register">Регистрация</a></p>
</div></div>
