<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Простой маршрутизатор: "МЕТОД /путь/{параметр}" => [Контроллер, метод].
 */
class Router
{
    /** @var array<int,array{0:string,1:string,2:array}> */
    private array $routes = [];

    /**
     * Регистрирует маршрут.
     *
     * @param string $method  GET или POST
     * @param string $pattern Шаблон пути, например "/seeds/{id}"
     * @param array  $handler [КлассКонтроллера::class, 'метод']
     * @return void
     */
    public function add(string $method, string $pattern, array $handler): void
    {
        $regex = '#^' . preg_replace('#\{(\w+)\}#', '(?P<$1>[^/]+)', $pattern) . '$#';
        $this->routes[] = [$method, $regex, $handler];
    }

    /**
     * Находит подходящий маршрут и вызывает контроллер.
     *
     * @param string $method Метод запроса
     * @param string $path   Путь запроса
     * @return void
     */
    public function dispatch(string $method, string $path): void
    {
        $path = rtrim($path, '/') ?: '/';
        foreach ($this->routes as [$m, $regex, $handler]) {
            if ($m === $method && preg_match($regex, $path, $matches)) {
                $params = array_filter($matches, 'is_string', ARRAY_FILTER_USE_KEY);
                [$class, $action] = $handler;
                (new $class())->$action(...array_values($params));
                return;
            }
        }
        http_response_code(404);
        View::render('error', ['code' => 404, 'message' => 'Страница не найдена.']);
    }
}
