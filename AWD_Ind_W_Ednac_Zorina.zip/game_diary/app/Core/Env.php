<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Минимальный загрузчик переменных окружения из файла .env.
 */
class Env
{
    /** @var array<string,string> */
    private static array $vars = [];

    /**
     * Читает файл .env и сохраняет пары КЛЮЧ=ЗНАЧЕНИЕ.
     *
     * @param string $path Путь к файлу .env
     * @return void
     */
    public static function load(string $path): void
    {
        if (!is_file($path)) {
            return;
        }
        foreach (file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
            $line = trim($line);
            if ($line === '' || $line[0] === '#' || !str_contains($line, '=')) {
                continue;
            }
            [$key, $value] = explode('=', $line, 2);
            self::$vars[trim($key)] = trim($value);
        }
    }

    /**
     * Возвращает значение переменной.
     *
     * @param string $key     Имя переменной
     * @param string $default Значение по умолчанию
     * @return string
     */
    public static function get(string $key, string $default = ''): string
    {
        return self::$vars[$key] ?? $default;
    }
}
