<?php
declare(strict_types=1);

namespace App\Core;

use PDO;

/**
 * Единая точка подключения к MySQL (Singleton). Все запросы идут через PDO.
 */
class Database
{
    private static ?PDO $pdo = null;

    /**
     * Возвращает подключение, создавая его при первом вызове.
     *
     * @return PDO
     */
    public static function get(): PDO
    {
        if (self::$pdo === null) {
            $dsn = sprintf(
                'mysql:host=%s;dbname=%s;charset=utf8mb4',
                Env::get('DB_HOST', '127.0.0.1'),
                Env::get('DB_NAME', 'seedvault')
            );
            self::$pdo = new PDO($dsn, Env::get('DB_USER', 'root'), Env::get('DB_PASS'), [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        }
        return self::$pdo;
    }

    /**
     * Создаёт подключение к серверу без выбора БД (нужно установщику).
     *
     * @return PDO
     */
    public static function server(): PDO
    {
        $dsn = sprintf('mysql:host=%s;charset=utf8mb4', Env::get('DB_HOST', '127.0.0.1'));
        return new PDO($dsn, Env::get('DB_USER', 'root'), Env::get('DB_PASS'), [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        ]);
    }
}
