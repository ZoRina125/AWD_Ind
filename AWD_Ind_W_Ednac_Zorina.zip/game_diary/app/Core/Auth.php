<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Проверка авторизации и ролей на основе переменных сессии.
 */
class Auth
{
    /** @return bool Вошёл ли пользователь */
    public static function check(): bool
    {
        return isset($_SESSION['user_id']);
    }

    /** @return int|null ID текущего пользователя */
    public static function id(): ?int
    {
        return self::check() ? (int)$_SESSION['user_id'] : null;
    }

    /** @return bool Является ли пользователь администратором */
    public static function isAdmin(): bool
    {
        return ($_SESSION['role'] ?? '') === 'admin';
    }

    /**
     * Сохраняет пользователя в сессии после успешного входа.
     *
     * @param array $user Строка из таблицы users
     * @return void
     */
    public static function login(array $user): void
    {
        session_regenerate_id(true); // защита от фиксации сессии
        $_SESSION['user_id']  = (int)$user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role']     = $user['role'];
    }

    /**
     * Полностью завершает сессию.
     *
     * @return void
     */
    public static function logout(): void
    {
        $_SESSION = [];
        session_destroy();
    }

    /**
     * Требует вход в систему, иначе перенаправляет на /login.
     *
     * @return void
     */
    public static function requireLogin(): void
    {
        if (!self::check()) {
            Flash::set('warning', 'Для этого действия нужно войти в систему.');
            View::redirect('/login');
        }
    }

    /**
     * Требует роль администратора, иначе ответ 403.
     *
     * @return void
     */
    public static function requireAdmin(): void
    {
        self::requireLogin();
        if (!self::isAdmin()) {
            http_response_code(403);
            View::render('error', ['code' => 403, 'message' => 'Доступ запрещён: нужна роль администратора.']);
            exit;
        }
    }
}
