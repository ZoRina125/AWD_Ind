<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Защита POST-форм от CSRF-атак с помощью токена в сессии.
 */
class Csrf
{
    /**
     * Возвращает (и при необходимости создаёт) токен текущей сессии.
     *
     * @return string
     */
    public static function token(): string
    {
        if (empty($_SESSION['csrf'])) {
            $_SESSION['csrf'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf'];
    }

    /**
     * Возвращает готовое скрытое поле для вставки в форму.
     *
     * @return string HTML
     */
    public static function field(): string
    {
        return '<input type="hidden" name="csrf" value="' . self::token() . '">';
    }

    /**
     * Проверяет токен из формы; при несовпадении завершает запрос с кодом 403.
     *
     * @return void
     */
    public static function check(): void
    {
        $sent = (string)($_POST['csrf'] ?? '');
        if (!hash_equals($_SESSION['csrf'] ?? '', $sent)) {
            http_response_code(403);
            exit('Неверный CSRF-токен. Обновите страницу и повторите действие.');
        }
    }
}
