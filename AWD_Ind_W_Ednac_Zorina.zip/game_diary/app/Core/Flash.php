<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Одноразовые сообщения пользователю (хранятся в сессии до следующего показа).
 */
class Flash
{
    /**
     * Добавляет сообщение.
     *
     * @param string $type    success | danger | warning | info
     * @param string $message Текст сообщения
     * @return void
     */
    public static function set(string $type, string $message): void
    {
        $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
    }

    /**
     * Возвращает все сообщения и очищает очередь.
     *
     * @return array<int,array{type:string,message:string}>
     */
    public static function pull(): array
    {
        $all = $_SESSION['flash'] ?? [];
        unset($_SESSION['flash']);
        return $all;
    }
}
