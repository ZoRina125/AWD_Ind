<?php
declare(strict_types=1);

namespace App\Core;

use PHPMailer\PHPMailer\PHPMailer;

/**
 * Отправка писем. Использует PHPMailer, если он установлен через Composer.
 * Если MAIL_HOST пуст или PHPMailer недоступен, письмо пишется в storage/mail.log
 * (удобно для демонстрации восстановления пароля без почтового сервера).
 */
class Mailer
{
    /**
     * Отправляет письмо.
     *
     * @param string $to      Адрес получателя
     * @param string $subject Тема
     * @param string $body    Текст письма
     * @return bool true, если письмо отправлено или записано в лог
     */
    public static function send(string $to, string $subject, string $body): bool
    {
        $host = Env::get('MAIL_HOST');
        if ($host !== '' && class_exists(PHPMailer::class)) {
            try {
                $mail = new PHPMailer(true);
                $mail->isSMTP();
                $mail->Host = $host;
                $mail->Port = (int)Env::get('MAIL_PORT', '25');
                $user = Env::get('MAIL_USER');
                $mail->SMTPAuth = $user !== '';
                if ($user !== '') {
                    $mail->Username = $user;
                    $mail->Password = Env::get('MAIL_PASS');
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                }
                $mail->CharSet = 'UTF-8';
                $mail->setFrom(Env::get('MAIL_FROM', 'noreply@seedvault.local'), 'SeedVault');
                $mail->addAddress($to);
                $mail->Subject = $subject;
                $mail->Body = $body;
                $mail->send();
                return true;
            } catch (\Throwable $e) {
                // при ошибке SMTP падаем в лог, чтобы работа не блокировалась
            }
        }
        $entry = sprintf("[%s] To: %s\nSubject: %s\n%s\n\n", date('c'), $to, $subject, $body);
        return file_put_contents(__DIR__ . '/../../storage/mail.log', $entry, FILE_APPEND) !== false;
    }
}
