<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Отрисовка шаблонов, экранирование и редиректы.
 */
class View
{
    /**
     * Отрисовывает шаблон внутри общего layout.
     *
     * @param string $template Путь внутри app/Views без .php, например "seeds/index"
     * @param array  $data     Переменные для шаблона
     * @return void
     */
    public static function render(string $template, array $data = []): void
    {
        extract($data, EXTR_SKIP);
        ob_start();
        require __DIR__ . '/../Views/' . $template . '.php';
        $content = ob_get_clean();
        $title = $title ?? 'SeedVault';
        require __DIR__ . '/../Views/layout/main.php';
    }

    /**
     * Экранирует строку для безопасного вывода в HTML (защита от XSS).
     *
     * @param mixed $value Значение
     * @return string
     */
    public static function e(mixed $value): string
    {
        return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
    }

    /**
     * Перенаправляет на другой адрес и завершает выполнение.
     *
     * @param string $url Относительный адрес
     * @return never
     */
    public static function redirect(string $url): never
    {
        header('Location: ' . $url);
        exit;
    }
}
