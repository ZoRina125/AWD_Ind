<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

/**
 * Работа с таблицей users.
 */
class User
{
    /**
     * Ищет пользователя по логину.
     *
     * @param string $username Логин
     * @return array|null Строка пользователя или null
     */
    public static function findByUsername(string $username): ?array
    {
        $st = Database::get()->prepare('SELECT * FROM users WHERE username = ?');
        $st->execute([$username]);
        return $st->fetch() ?: null;
    }

    /**
     * Ищет пользователя по email.
     *
     * @param string $email Email
     * @return array|null
     */
    public static function findByEmail(string $email): ?array
    {
        $st = Database::get()->prepare('SELECT * FROM users WHERE email = ?');
        $st->execute([$email]);
        return $st->fetch() ?: null;
    }

    /**
     * Ищет пользователя по ID.
     *
     * @param int $id ID
     * @return array|null
     */
    public static function find(int $id): ?array
    {
        $st = Database::get()->prepare('SELECT * FROM users WHERE id = ?');
        $st->execute([$id]);
        return $st->fetch() ?: null;
    }

    /**
     * Проверяет, занят ли логин или email.
     *
     * @param string $username Логин
     * @param string $email    Email
     * @return bool
     */
    public static function exists(string $username, string $email): bool
    {
        $st = Database::get()->prepare('SELECT 1 FROM users WHERE username = ? OR email = ?');
        $st->execute([$username, $email]);
        return (bool)$st->fetch();
    }

    /**
     * Создаёт пользователя; пароль хешируется функцией password_hash().
     *
     * @param string $username Логин
     * @param string $email    Email
     * @param string $password Пароль в открытом виде
     * @param string $role     user | admin
     * @return int ID созданного пользователя
     */
    public static function create(string $username, string $email, string $password, string $role = 'user'): int
    {
        $pdo = Database::get();
        $pdo->prepare('INSERT INTO users (username, email, password_hash, role) VALUES (?,?,?,?)')
            ->execute([$username, $email, password_hash($password, PASSWORD_DEFAULT), $role]);
        return (int)$pdo->lastInsertId();
    }

    /**
     * Обновляет пароль пользователя.
     *
     * @param int    $id       ID пользователя
     * @param string $password Новый пароль
     * @return void
     */
    public static function updatePassword(int $id, string $password): void
    {
        Database::get()->prepare('UPDATE users SET password_hash = ? WHERE id = ?')
            ->execute([password_hash($password, PASSWORD_DEFAULT), $id]);
    }

    /**
     * Возвращает всех пользователей с количеством их сидов.
     *
     * @return array
     */
    public static function allWithStats(): array
    {
        return Database::get()->query(
            'SELECT u.id, u.username, u.email, u.role, u.created_at, COUNT(s.id) AS seeds_count
             FROM users u LEFT JOIN seeds s ON s.user_id = u.id
             GROUP BY u.id ORDER BY u.id'
        )->fetchAll();
    }

    /**
     * Меняет роль пользователя.
     *
     * @param int    $id   ID
     * @param string $role user | admin
     * @return void
     */
    public static function setRole(int $id, string $role): void
    {
        Database::get()->prepare('UPDATE users SET role = ? WHERE id = ?')->execute([$role, $id]);
    }

    /**
     * Удаляет пользователя (его сиды удаляются каскадно).
     *
     * @param int $id ID
     * @return void
     */
    public static function delete(int $id): void
    {
        Database::get()->prepare('DELETE FROM users WHERE id = ?')->execute([$id]);
    }

    /** @return int Общее число пользователей */
    public static function count(): int
    {
        return (int)Database::get()->query('SELECT COUNT(*) FROM users')->fetchColumn();
    }
}
