<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

/**
 * Токены восстановления пароля. В БД хранится только SHA-256 хеш токена.
 */
class PasswordReset
{
    /**
     * Создаёт токен для пользователя (старые токены удаляются).
     *
     * @param int $userId ID пользователя
     * @return string Токен в открытом виде (отправляется в письме)
     */
    public static function create(int $userId): string
    {
        $pdo = Database::get();
        $pdo->prepare('DELETE FROM password_resets WHERE user_id = ?')->execute([$userId]);

        $token = bin2hex(random_bytes(32));
        $pdo->prepare('INSERT INTO password_resets (user_id, token_hash, expires_at)
                       VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 1 HOUR))')
            ->execute([$userId, hash('sha256', $token)]);
        return $token;
    }

    /**
     * Возвращает ID пользователя по действующему токену.
     *
     * @param string $token Токен из ссылки
     * @return int|null ID пользователя или null, если токен неверный/просрочен
     */
    public static function findUserId(string $token): ?int
    {
        $st = Database::get()->prepare('SELECT user_id FROM password_resets WHERE token_hash = ? AND expires_at > NOW()');
        $st->execute([hash('sha256', $token)]);
        $id = $st->fetchColumn();
        return $id === false ? null : (int)$id;
    }

    /**
     * Удаляет все токены пользователя.
     *
     * @param int $userId ID пользователя
     * @return void
     */
    public static function clear(int $userId): void
    {
        Database::get()->prepare('DELETE FROM password_resets WHERE user_id = ?')->execute([$userId]);
    }
}
