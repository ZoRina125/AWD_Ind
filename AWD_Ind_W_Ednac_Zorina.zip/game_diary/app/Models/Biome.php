<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

/**
 * Справочник биомов (таблица biomes).
 */
class Biome
{
    /** @return array Все биомы по алфавиту */
    public static function all(): array
    {
        return Database::get()->query('SELECT * FROM biomes ORDER BY name')->fetchAll();
    }

    /**
     * Находит биом по ID.
     *
     * @param int $id ID
     * @return array|null
     */
    public static function find(int $id): ?array
    {
        $st = Database::get()->prepare('SELECT * FROM biomes WHERE id = ?');
        $st->execute([$id]);
        return $st->fetch() ?: null;
    }

    /**
     * Добавляет биом.
     *
     * @param string $name Название
     * @return void
     */
    public static function create(string $name): void
    {
        Database::get()->prepare('INSERT INTO biomes (name) VALUES (?)')->execute([$name]);
    }

    /**
     * Переименовывает биом.
     *
     * @param int    $id   ID
     * @param string $name Новое название
     * @return void
     */
    public static function update(int $id, string $name): void
    {
        Database::get()->prepare('UPDATE biomes SET name = ? WHERE id = ?')->execute([$name, $id]);
    }

    /**
     * Удаляет биом. Бросает PDOException, если на него ссылаются сиды.
     *
     * @param int $id ID
     * @return void
     */
    public static function delete(int $id): void
    {
        Database::get()->prepare('DELETE FROM biomes WHERE id = ?')->execute([$id]);
    }

    /**
     * Биомы с количеством сидов (для статистики), по убыванию популярности.
     *
     * @param int $limit Сколько строк вернуть
     * @return array
     */
    public static function popular(int $limit = 5): array
    {
        $limit = max(1, $limit);
        return Database::get()->query(
            "SELECT b.id, b.name, COUNT(s.id) AS cnt
             FROM biomes b LEFT JOIN seeds s ON s.biome_id = b.id
             GROUP BY b.id ORDER BY cnt DESC, b.name LIMIT $limit"
        )->fetchAll();
    }

    /**
     * Все биомы с количеством сидов (для админ-таблицы).
     *
     * @return array
     */
    public static function allWithCounts(): array
    {
        return Database::get()->query(
            'SELECT b.id, b.name, COUNT(s.id) AS cnt
             FROM biomes b LEFT JOIN seeds s ON s.biome_id = b.id
             GROUP BY b.id ORDER BY b.name'
        )->fetchAll();
    }
}
