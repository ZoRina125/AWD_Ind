<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

/**
 * Работа с таблицей seeds (сиды Minecraft).
 */
class Seed
{
    /** Допустимые версии игры для выпадающего списка. */
    public const VERSIONS = ['1.21', '1.20', '1.19', '1.18', '1.17', '1.16', '1.14', '1.12', '1.8'];
    public const EDITIONS = ['java' => 'Java', 'bedrock' => 'Bedrock'];
    public const DIFFICULTIES = [
        'peaceful' => 'Мирный', 'easy' => 'Лёгкий', 'normal' => 'Нормальный', 'hard' => 'Сложный',
    ];
    public const PER_PAGE = 9;

    private const BASE_SELECT =
        'SELECT s.*, b.name AS biome, u.username
         FROM seeds s
         JOIN biomes b ON b.id = s.biome_id
         JOIN users  u ON u.id = s.user_id';

    /**
     * Поиск сидов по фильтрам с пагинацией.
     *
     * @param array $f    Фильтры: q, edition, version, biome_id, difficulty, has_village
     * @param int   $page Номер страницы (с 1)
     * @return array{items:array,total:int,pages:int}
     */
    public static function search(array $f, int $page = 1): array
    {
        $where = ' WHERE 1=1';
        $params = [];

        if (($f['q'] ?? '') !== '') {
            $where .= ' AND (s.title LIKE ? OR s.description LIKE ? OR s.seed_value LIKE ?)';
            $like = '%' . addcslashes($f['q'], '%_\\') . '%';
            array_push($params, $like, $like, $like);
        }
        if (isset(self::EDITIONS[$f['edition'] ?? ''])) {
            $where .= ' AND s.edition = ?';
            $params[] = $f['edition'];
        }
        if (in_array($f['version'] ?? '', self::VERSIONS, true)) {
            $where .= ' AND s.version = ?';
            $params[] = $f['version'];
        }
        if ((int)($f['biome_id'] ?? 0) > 0) {
            $where .= ' AND s.biome_id = ?';
            $params[] = (int)$f['biome_id'];
        }
        if (isset(self::DIFFICULTIES[$f['difficulty'] ?? ''])) {
            $where .= ' AND s.difficulty = ?';
            $params[] = $f['difficulty'];
        }
        if (!empty($f['has_village'])) {
            $where .= ' AND s.has_village = 1';
        }

        $pdo = Database::get();
        $cnt = $pdo->prepare('SELECT COUNT(*) FROM seeds s' . $where);
        $cnt->execute($params);
        $total = (int)$cnt->fetchColumn();

        $pages = max(1, (int)ceil($total / self::PER_PAGE));
        $page = min(max(1, $page), $pages);
        $offset = ($page - 1) * self::PER_PAGE;
        $limit = self::PER_PAGE;

        $st = $pdo->prepare(self::BASE_SELECT . $where . " ORDER BY s.created_at DESC, s.id DESC LIMIT $limit OFFSET $offset");
        $st->execute($params);

        return ['items' => $st->fetchAll(), 'total' => $total, 'pages' => $pages, 'page' => $page];
    }

    /**
     * Последние добавленные сиды.
     *
     * @param int $limit Количество
     * @return array
     */
    public static function latest(int $limit = 6): array
    {
        $limit = max(1, $limit);
        return Database::get()->query(self::BASE_SELECT . " ORDER BY s.created_at DESC, s.id DESC LIMIT $limit")->fetchAll();
    }

    /**
     * Находит сид по ID вместе с названием биома и автором.
     *
     * @param int $id ID
     * @return array|null
     */
    public static function find(int $id): ?array
    {
        $st = Database::get()->prepare(self::BASE_SELECT . ' WHERE s.id = ?');
        $st->execute([$id]);
        return $st->fetch() ?: null;
    }

    /**
     * Сиды конкретного пользователя.
     *
     * @param int $userId ID пользователя
     * @return array
     */
    public static function byUser(int $userId): array
    {
        $st = Database::get()->prepare(self::BASE_SELECT . ' WHERE s.user_id = ? ORDER BY s.created_at DESC');
        $st->execute([$userId]);
        return $st->fetchAll();
    }

    /** @return array Все сиды (для админки) */
    public static function all(): array
    {
        return Database::get()->query(self::BASE_SELECT . ' ORDER BY s.id DESC')->fetchAll();
    }

    /**
     * Создаёт сид.
     *
     * @param int   $userId Автор
     * @param array $d      Проверенные данные формы
     * @return int ID нового сида
     */
    public static function create(int $userId, array $d): int
    {
        $pdo = Database::get();
        $pdo->prepare(
            'INSERT INTO seeds (user_id, biome_id, title, seed_value, edition, version, difficulty, has_village, description, image_url)
             VALUES (?,?,?,?,?,?,?,?,?,?)'
        )->execute([
            $userId, $d['biome_id'], $d['title'], $d['seed_value'], $d['edition'],
            $d['version'], $d['difficulty'], $d['has_village'], $d['description'], $d['image_url'] ?: null,
        ]);
        return (int)$pdo->lastInsertId();
    }

    /**
     * Обновляет сид.
     *
     * @param int   $id ID сида
     * @param array $d  Проверенные данные формы
     * @return void
     */
    public static function update(int $id, array $d): void
    {
        Database::get()->prepare(
            'UPDATE seeds SET biome_id=?, title=?, seed_value=?, edition=?, version=?, difficulty=?,
                              has_village=?, description=?, image_url=? WHERE id=?'
        )->execute([
            $d['biome_id'], $d['title'], $d['seed_value'], $d['edition'], $d['version'],
            $d['difficulty'], $d['has_village'], $d['description'], $d['image_url'] ?: null, $id,
        ]);
    }

    /**
     * Удаляет сид.
     *
     * @param int $id ID
     * @return void
     */
    public static function delete(int $id): void
    {
        Database::get()->prepare('DELETE FROM seeds WHERE id = ?')->execute([$id]);
    }

    /** @return int Общее число сидов */
    public static function count(): int
    {
        return (int)Database::get()->query('SELECT COUNT(*) FROM seeds')->fetchColumn();
    }

    /**
     * Пользователи с наибольшим числом сидов.
     *
     * @param int $limit Количество
     * @return array
     */
    public static function topAuthors(int $limit = 5): array
    {
        $limit = max(1, $limit);
        return Database::get()->query(
            "SELECT u.username, COUNT(s.id) AS cnt
             FROM users u JOIN seeds s ON s.user_id = u.id
             GROUP BY u.id ORDER BY cnt DESC, u.username LIMIT $limit"
        )->fetchAll();
    }
}
