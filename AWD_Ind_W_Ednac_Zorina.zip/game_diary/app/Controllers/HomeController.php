<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\View;
use App\Models\{Biome, Seed, User};

/**
 * Публичная главная страница: все блоки формируются из БД.
 */
class HomeController
{
    /**
     * Показывает последние сиды, популярные биомы и счётчики.
     *
     * @return void
     */
    public function index(): void
    {
        View::render('home', [
            'title'   => 'SeedVault: каталог сидов Minecraft',
            'latest'  => Seed::latest(6),
            'popular' => Biome::popular(5),
            'authors' => Seed::topAuthors(5),
            'seedsTotal' => Seed::count(),
            'usersTotal' => User::count(),
        ]);
    }
}
