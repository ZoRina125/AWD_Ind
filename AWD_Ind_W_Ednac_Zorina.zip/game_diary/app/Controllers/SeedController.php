<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\{Auth, Csrf, Flash, View};
use App\Models\{Biome, Seed};

/**
 * Поиск, просмотр, создание, редактирование и удаление сидов.
 */
class SeedController
{
    /**
     * Форма поиска + результаты (доступно всем).
     *
     * @return void
     */
    public function search(): void
    {
        $filters = [
            'q'           => trim((string)($_GET['q'] ?? '')),
            'edition'     => (string)($_GET['edition'] ?? ''),
            'version'     => (string)($_GET['version'] ?? ''),
            'biome_id'    => (string)($_GET['biome_id'] ?? ''),
            'difficulty'  => (string)($_GET['difficulty'] ?? ''),
            'has_village' => isset($_GET['has_village']) ? '1' : '',
        ];
        $result = Seed::search($filters, (int)($_GET['page'] ?? 1));
        View::render('seeds/index', [
            'title' => 'Поиск сидов', 'filters' => $filters, 'result' => $result, 'biomes' => Biome::all(),
        ]);
    }

    /**
     * Страница одного сида.
     *
     * @param string $id ID из URL
     * @return void
     */
    public function show(string $id): void
    {
        $seed = ctype_digit($id) ? Seed::find((int)$id) : null;
        if (!$seed) {
            http_response_code(404);
            View::render('error', ['code' => 404, 'message' => 'Сид не найден.']);
            return;
        }
        View::render('seeds/show', ['title' => $seed['title'], 'seed' => $seed, 'canEdit' => $this->canManage($seed)]);
    }

    /**
     * Личный кабинет: сиды текущего пользователя (защищённый раздел).
     *
     * @return void
     */
    public function mine(): void
    {
        Auth::requireLogin();
        View::render('seeds/my', ['title' => 'Мои сиды', 'seeds' => Seed::byUser((int)Auth::id())]);
    }

    /** @return void Пустая форма создания */
    public function showCreate(): void
    {
        Auth::requireLogin();
        $this->form('Добавить сид', '/seeds/create', [], []);
    }

    /**
     * Создание сида: серверная валидация и запись в БД.
     *
     * @return void
     */
    public function create(): void
    {
        Auth::requireLogin();
        Csrf::check();
        [$data, $errors] = self::validate($_POST);
        if ($errors) {
            $this->form('Добавить сид', '/seeds/create', $data, $errors);
            return;
        }
        $id = Seed::create((int)Auth::id(), $data);
        Flash::set('success', 'Сид добавлен!');
        View::redirect('/seeds/' . $id);
    }

    /**
     * Форма редактирования (только автор или администратор).
     *
     * @param string $id ID сида
     * @return void
     */
    public function showEdit(string $id): void
    {
        $seed = $this->loadManageable($id);
        $seed['has_village'] = (string)$seed['has_village'];
        $this->form('Редактировать сид', '/seeds/' . $seed['id'] . '/edit', $seed, []);
    }

    /**
     * Сохранение изменений сида.
     *
     * @param string $id ID сида
     * @return void
     */
    public function update(string $id): void
    {
        $seed = $this->loadManageable($id);
        Csrf::check();
        [$data, $errors] = self::validate($_POST);
        if ($errors) {
            $this->form('Редактировать сид', '/seeds/' . $seed['id'] . '/edit', $data, $errors);
            return;
        }
        Seed::update((int)$seed['id'], $data);
        Flash::set('success', 'Изменения сохранены.');
        View::redirect('/seeds/' . $seed['id']);
    }

    /**
     * Удаление сида (автор или администратор).
     *
     * @param string $id ID сида
     * @return void
     */
    public function delete(string $id): void
    {
        $seed = $this->loadManageable($id);
        Csrf::check();
        Seed::delete((int)$seed['id']);
        Flash::set('success', 'Сид удалён.');
        View::redirect(Auth::isAdmin() ? '/admin/seeds' : '/my');
    }

    /**
     * Серверная валидация формы сида.
     *
     * @param array $in Данные из $_POST
     * @return array{0:array,1:array<string,string>} [очищенные данные, ошибки]
     */
    public static function validate(array $in): array
    {
        $d = [
            'title'       => trim((string)($in['title'] ?? '')),
            'seed_value'  => trim((string)($in['seed_value'] ?? '')),
            'edition'     => (string)($in['edition'] ?? ''),
            'version'     => (string)($in['version'] ?? ''),
            'biome_id'    => (int)($in['biome_id'] ?? 0),
            'difficulty'  => (string)($in['difficulty'] ?? ''),
            'has_village' => !empty($in['has_village']) ? 1 : 0,
            'description' => trim((string)($in['description'] ?? '')),
            'image_url'   => trim((string)($in['image_url'] ?? '')),
        ];
        $e = [];

        $len = mb_strlen($d['title']);
        if ($len < 3 || $len > 100) {
            $e['title'] = 'Название: от 3 до 100 символов.';
        }
        if (!preg_match('/^-?\d{1,19}$/', $d['seed_value'])) {
            $e['seed_value'] = 'Сид: целое число (можно со знаком минус), до 19 цифр.';
        }
        if (!isset(Seed::EDITIONS[$d['edition']])) {
            $e['edition'] = 'Выберите редакцию игры.';
        }
        if (!in_array($d['version'], Seed::VERSIONS, true)) {
            $e['version'] = 'Выберите версию из списка.';
        }
        if (Biome::find($d['biome_id']) === null) {
            $e['biome_id'] = 'Выберите биом из списка.';
        }
        if (!isset(Seed::DIFFICULTIES[$d['difficulty']])) {
            $e['difficulty'] = 'Выберите сложность.';
        }
        $dl = mb_strlen($d['description']);
        if ($dl < 10 || $dl > 2000) {
            $e['description'] = 'Описание: от 10 до 2000 символов.';
        }
        if ($d['image_url'] !== '') {
            $scheme = strtolower((string)parse_url($d['image_url'], PHP_URL_SCHEME));
            if (strlen($d['image_url']) > 255 || !filter_var($d['image_url'], FILTER_VALIDATE_URL)
                || !in_array($scheme, ['http', 'https'], true)) {
                $e['image_url'] = 'Ссылка на скриншот должна начинаться с http:// или https://.';
            }
        }
        return [$d, $e];
    }

    /**
     * Показывает форму создания/редактирования.
     *
     * @param string $heading Заголовок
     * @param string $action  URL отправки формы
     * @param array  $old     Значения полей
     * @param array  $errors  Ошибки
     * @return void
     */
    private function form(string $heading, string $action, array $old, array $errors): void
    {
        View::render('seeds/form', [
            'title' => $heading, 'heading' => $heading, 'action' => $action,
            'old' => $old, 'errors' => $errors, 'biomes' => Biome::all(),
        ]);
    }

    /**
     * Может ли текущий пользователь изменять сид (автор или админ).
     *
     * @param array $seed Строка сида
     * @return bool
     */
    private function canManage(array $seed): bool
    {
        return Auth::check() && (Auth::isAdmin() || (int)$seed['user_id'] === Auth::id());
    }

    /**
     * Загружает сид и проверяет права; иначе 404/403.
     *
     * @param string $id ID из URL
     * @return array Строка сида
     */
    private function loadManageable(string $id): array
    {
        Auth::requireLogin();
        $seed = ctype_digit($id) ? Seed::find((int)$id) : null;
        if (!$seed) {
            http_response_code(404);
            View::render('error', ['code' => 404, 'message' => 'Сид не найден.']);
            exit;
        }
        if (!$this->canManage($seed)) {
            http_response_code(403);
            View::render('error', ['code' => 403, 'message' => 'Редактировать можно только свои сиды.']);
            exit;
        }
        return $seed;
    }
}
