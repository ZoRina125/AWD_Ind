<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\{Auth, Csrf, Flash, View};
use App\Models\{Biome, Seed, User};

/**
 * Панель администратора. Каждый метод начинается с Auth::requireAdmin().
 */
class AdminController
{
    /** @return void Дашборд со статистикой */
    public function dashboard(): void
    {
        Auth::requireAdmin();
        View::render('admin/dashboard', [
            'title' => 'Админ-панель',
            'usersTotal' => User::count(),
            'seedsTotal' => Seed::count(),
            'biomes'     => Biome::popular(9),
            'authors'    => Seed::topAuthors(5),
        ]);
    }

    /** @return void Список пользователей */
    public function users(): void
    {
        Auth::requireAdmin();
        View::render('admin/users', ['title' => 'Пользователи', 'users' => User::allWithStats()]);
    }

    /**
     * Смена роли пользователя (нельзя изменить собственную).
     *
     * @param string $id ID пользователя
     * @return void
     */
    public function changeRole(string $id): void
    {
        Auth::requireAdmin();
        Csrf::check();
        $role = (string)($_POST['role'] ?? '');
        if (!ctype_digit($id) || !in_array($role, ['user', 'admin'], true) || (int)$id === Auth::id()) {
            Flash::set('danger', 'Нельзя выполнить это действие (в том числе над собственной учётной записью).');
        } elseif (User::find((int)$id)) {
            User::setRole((int)$id, $role);
            Flash::set('success', 'Роль изменена.');
        }
        View::redirect('/admin/users');
    }

    /**
     * Удаление пользователя вместе с его сидами (себя удалить нельзя).
     *
     * @param string $id ID пользователя
     * @return void
     */
    public function deleteUser(string $id): void
    {
        Auth::requireAdmin();
        Csrf::check();
        if (!ctype_digit($id) || (int)$id === Auth::id()) {
            Flash::set('danger', 'Нельзя удалить собственную учётную запись.');
        } else {
            User::delete((int)$id);
            Flash::set('success', 'Пользователь удалён.');
        }
        View::redirect('/admin/users');
    }

    /** @return void Форма создания администратора */
    public function showCreateAdmin(): void
    {
        Auth::requireAdmin();
        View::render('admin/create_admin', ['title' => 'Новый администратор', 'errors' => [], 'old' => []]);
    }

    /**
     * Создаёт учётную запись с ролью admin.
     *
     * @return void
     */
    public function createAdmin(): void
    {
        Auth::requireAdmin();
        Csrf::check();
        $username = trim($_POST['username'] ?? '');
        $email    = trim($_POST['email'] ?? '');
        $password = (string)($_POST['password'] ?? '');

        $errors = AuthController::validateAccount($username, $email, $password);
        if (!$errors && User::exists($username, $email)) {
            $errors['username'] = 'Такой ник или email уже занят.';
        }
        if ($errors) {
            View::render('admin/create_admin', [
                'title' => 'Новый администратор', 'errors' => $errors,
                'old' => ['username' => $username, 'email' => $email],
            ]);
            return;
        }
        User::create($username, $email, $password, 'admin');
        Flash::set('success', "Администратор $username создан.");
        View::redirect('/admin/users');
    }

    /** @return void Все сиды с кнопками правки/удаления */
    public function seeds(): void
    {
        Auth::requireAdmin();
        View::render('admin/seeds', ['title' => 'Управление сидами', 'seeds' => Seed::all()]);
    }

    /** @return void Справочник биомов */
    public function biomes(): void
    {
        Auth::requireAdmin();
        View::render('admin/biomes', ['title' => 'Биомы', 'biomes' => Biome::allWithCounts()]);
    }

    /**
     * Проверяет название биома.
     *
     * @param string $name Название
     * @return string|null Текст ошибки или null
     */
    private function biomeError(string $name): ?string
    {
        $len = mb_strlen($name);
        return ($len < 2 || $len > 50) ? 'Название биома: от 2 до 50 символов.' : null;
    }

    /** @return void Добавление биома */
    public function createBiome(): void
    {
        Auth::requireAdmin();
        Csrf::check();
        $name = trim($_POST['name'] ?? '');
        if ($err = $this->biomeError($name)) {
            Flash::set('danger', $err);
        } else {
            try {
                Biome::create($name);
                Flash::set('success', 'Биом добавлен.');
            } catch (\PDOException) {
                Flash::set('danger', 'Такой биом уже существует.');
            }
        }
        View::redirect('/admin/biomes');
    }

    /**
     * Переименование биома.
     *
     * @param string $id ID биома
     * @return void
     */
    public function updateBiome(string $id): void
    {
        Auth::requireAdmin();
        Csrf::check();
        $name = trim($_POST['name'] ?? '');
        if (!ctype_digit($id) || ($err = $this->biomeError($name))) {
            Flash::set('danger', $err ?? 'Некорректный запрос.');
        } else {
            try {
                Biome::update((int)$id, $name);
                Flash::set('success', 'Биом обновлён.');
            } catch (\PDOException) {
                Flash::set('danger', 'Биом с таким названием уже существует.');
            }
        }
        View::redirect('/admin/biomes');
    }

    /**
     * Удаление биома (запрещено, если есть сиды с этим биомом).
     *
     * @param string $id ID биома
     * @return void
     */
    public function deleteBiome(string $id): void
    {
        Auth::requireAdmin();
        Csrf::check();
        if (ctype_digit($id)) {
            try {
                Biome::delete((int)$id);
                Flash::set('success', 'Биом удалён.');
            } catch (\PDOException) {
                Flash::set('danger', 'Нельзя удалить биом, который используется в сидах.');
            }
        }
        View::redirect('/admin/biomes');
    }
}
