<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\{Auth, Csrf, Env, Flash, Mailer, View};
use App\Models\{PasswordReset, User};

/**
 * Регистрация, вход, выход и восстановление пароля.
 */
class AuthController
{
    private const MAX_ATTEMPTS = 5;
    private const LOCK_SECONDS = 60;

    /**
     * Проверяет поля регистрации/смены пароля.
     *
     * @param string|null $username Логин (null, если не проверять)
     * @param string|null $email    Email (null, если не проверять)
     * @param string|null $password Пароль (null, если не проверять)
     * @return array<string,string> Ошибки по именам полей
     */
    public static function validateAccount(?string $username, ?string $email, ?string $password): array
    {
        $errors = [];
        if ($username !== null && !preg_match('/^[A-Za-z0-9_]{3,30}$/', $username)) {
            $errors['username'] = 'Ник: 3-30 символов, латиница, цифры и _.';
        }
        if ($email !== null && (strlen($email) > 100 || !filter_var($email, FILTER_VALIDATE_EMAIL))) {
            $errors['email'] = 'Введите корректный email (до 100 символов).';
        }
        if ($password !== null) {
            if (strlen($password) < 8 || strlen($password) > 72) {
                $errors['password'] = 'Пароль: от 8 до 72 символов.';
            } elseif (!preg_match('/[A-Za-z]/', $password) || !preg_match('/\d/', $password)) {
                $errors['password'] = 'Пароль должен содержать буквы и цифры.';
            }
        }
        return $errors;
    }

    /** @return void Форма регистрации */
    public function showRegister(array $errors = [], array $old = []): void
    {
        View::render('auth/register', ['title' => 'Регистрация', 'errors' => $errors, 'old' => $old]);
    }

    /**
     * Регистрация: валидация, проверка уникальности, хеширование пароля, запись в БД.
     *
     * @return void
     */
    public function register(): void
    {
        Csrf::check();
        $username = trim($_POST['username'] ?? '');
        $email    = trim($_POST['email'] ?? '');
        $password = (string)($_POST['password'] ?? '');
        $confirm  = (string)($_POST['password_confirm'] ?? '');

        $errors = self::validateAccount($username, $email, $password);
        if ($password !== $confirm) {
            $errors['password_confirm'] = 'Пароли не совпадают.';
        }
        if (!$errors && User::exists($username, $email)) {
            $errors['username'] = 'Такой ник или email уже занят.';
        }
        if ($errors) {
            $this->showRegister($errors, ['username' => $username, 'email' => $email]);
            return;
        }

        User::create($username, $email, $password);
        Flash::set('success', 'Регистрация прошла успешно. Теперь войдите.');
        View::redirect('/login');
    }

    /** @return void Форма входа */
    public function showLogin(): void
    {
        View::render('auth/login', ['title' => 'Вход', 'error' => null, 'old' => '']);
    }

    /**
     * Вход: ограничение числа попыток, проверка пароля, запись в сессию.
     *
     * @return void
     */
    public function login(): void
    {
        Csrf::check();
        $username = trim($_POST['username'] ?? '');

        // Простая защита от подбора пароля: блокировка на минуту после 5 неудач
        $lockedUntil = $_SESSION['lock_until'] ?? 0;
        if ($lockedUntil > time()) {
            View::render('auth/login', [
                'title' => 'Вход', 'old' => $username,
                'error' => 'Слишком много попыток. Подождите ' . ($lockedUntil - time()) . ' сек.',
            ]);
            return;
        }

        $user = User::findByUsername($username);
        if ($user && password_verify((string)($_POST['password'] ?? ''), $user['password_hash'])) {
            unset($_SESSION['attempts'], $_SESSION['lock_until']);
            Auth::login($user);
            Flash::set('success', 'Добро пожаловать, ' . $user['username'] . '!');
            View::redirect('/');
        }

        $_SESSION['attempts'] = ($_SESSION['attempts'] ?? 0) + 1;
        if ($_SESSION['attempts'] >= self::MAX_ATTEMPTS) {
            $_SESSION['lock_until'] = time() + self::LOCK_SECONDS;
            $_SESSION['attempts'] = 0;
        }
        View::render('auth/login', ['title' => 'Вход', 'old' => $username, 'error' => 'Неверный логин или пароль.']);
    }

    /** @return void Выход из системы (только POST + CSRF) */
    public function logout(): void
    {
        Csrf::check();
        Auth::logout();
        session_start();
        Flash::set('info', 'Вы вышли из системы.');
        View::redirect('/');
    }

    /** @return void Форма «Забыли пароль?» */
    public function showForgot(): void
    {
        View::render('auth/forgot', ['title' => 'Восстановление пароля', 'error' => null]);
    }

    /**
     * Создаёт токен и отправляет письмо. Ответ одинаков для существующих и
     * несуществующих email, чтобы нельзя было узнать зарегистрированные адреса.
     *
     * @return void
     */
    public function forgot(): void
    {
        Csrf::check();
        $email = trim($_POST['email'] ?? '');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            View::render('auth/forgot', ['title' => 'Восстановление пароля', 'error' => 'Введите корректный email.']);
            return;
        }
        $user = User::findByEmail($email);
        if ($user) {
            $token = PasswordReset::create((int)$user['id']);
            $link = rtrim(Env::get('APP_URL', 'http://localhost:8000'), '/') . '/reset?token=' . $token;
            Mailer::send($email, 'Восстановление пароля SeedVault',
                "Здравствуйте, {$user['username']}!\n\nЧтобы задать новый пароль, перейдите по ссылке (действует 1 час):\n$link\n\nЕсли это были не вы, просто проигнорируйте письмо.");
        }
        Flash::set('info', 'Если такой email зарегистрирован, мы отправили на него ссылку для сброса пароля.');
        View::redirect('/login');
    }

    /** @return void Форма нового пароля (по токену из письма) */
    public function showReset(): void
    {
        $token = (string)($_GET['token'] ?? '');
        if (PasswordReset::findUserId($token) === null) {
            Flash::set('danger', 'Ссылка недействительна или устарела.');
            View::redirect('/forgot');
        }
        View::render('auth/reset', ['title' => 'Новый пароль', 'token' => $token, 'errors' => []]);
    }

    /**
     * Сохраняет новый пароль, если токен действителен.
     *
     * @return void
     */
    public function reset(): void
    {
        Csrf::check();
        $token    = (string)($_POST['token'] ?? '');
        $password = (string)($_POST['password'] ?? '');
        $userId   = PasswordReset::findUserId($token);
        if ($userId === null) {
            Flash::set('danger', 'Ссылка недействительна или устарела.');
            View::redirect('/forgot');
        }

        $errors = self::validateAccount(null, null, $password);
        if ($password !== (string)($_POST['password_confirm'] ?? '')) {
            $errors['password_confirm'] = 'Пароли не совпадают.';
        }
        if ($errors) {
            View::render('auth/reset', ['title' => 'Новый пароль', 'token' => $token, 'errors' => $errors]);
            return;
        }

        User::updatePassword($userId, $password);
        PasswordReset::clear($userId);
        Flash::set('success', 'Пароль изменён. Войдите с новым паролем.');
        View::redirect('/login');
    }
}
